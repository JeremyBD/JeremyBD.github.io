//Jeremy De La Cruz
gameProgress = 0;
jumptimes = 0;
//attacktimes = 0;

function startGame()
{
	if(gameProgress <= 0)
	{
		IDLE_RIGHT = "images/idleRomanRight.gif";
		IDLE_LEFT = "images/idleRomanLeft.gif";
		WALKING_RIGHT = "images/walkingRomanRight.gif";
		WALKING_LEFT = "images/walkingRomanLeft.gif";
		BLOCKING_RIGHT = "images/blockingRomanRight.gif";
		BLOCKING_LEFT = "images/blockingRomanLeft.gif";
		ATTACKING_RIGHT = "images/attackingRomanRight.gif";
		ATTACKING_LEFT = "images/attackingRomanLeft.gif";
		PLAYER.src = IDLE_RIGHT;
	}
	positionX = 0;
	positionY = 390;
	MOVEMENT_SPEED = 4.5;
	PLAYER.style.top = positionY + "px";
	PLAYER.style.left = positionX + "px";
	PlayerFace = "";
}

function checkPlayer()
{
	if(PLAYER.src.slice(PLAYER.src.length-25,PLAYER.src.length) == IDLE_RIGHT)
	{
		PlayerFace = IDLE_RIGHT;
	}
	if(PLAYER.src.slice(PLAYER.src.length-24,PLAYER.src.length) == IDLE_LEFT)
	{
		PlayerFace = IDLE_LEFT;
	}
	if(PLAYER.src.slice(PLAYER.src.length-28,PLAYER.src.length) == WALKING_RIGHT)
	{
		PlayerFace = WALKING_RIGHT;
	}
	if(PLAYER.src.slice(PLAYER.src.length-27,PLAYER.src.length) == WALKING_LEFT)
	{
		PlayerFace = WALKING_LEFT;
	}
	if(PLAYER.src.slice(PLAYER.src.length-29,PLAYER.src.length) == BLOCKING_RIGHT)
	{
		PlayerFace = BLOCKING_RIGHT;
	}
	if(PLAYER.src.slice(PLAYER.src.length-28,PLAYER.src.length) == BLOCKING_LEFT)
	{
		PlayerFace = BLOCKING_LEFT;
	}
	if(PLAYER.src.slice(PLAYER.src.length-30,PLAYER.src.length) == ATTACKING_RIGHT)
	{
		PlayerFace = ATTACKING_RIGHT;
	}
	if(PLAYER.src.slice(PLAYER.src.length-29,PLAYER.src.length) == ATTACKING_LEFT)
	{
		PlayerFace = ATTACKING_LEFT;
	}
}

function moveLeft(e)
{
	if (e.which == 65 || e.keyCode == 65)
	{
		//Left
		positionX -= MOVEMENT_SPEED;
		checkPlayer();
		if(PlayerFace != WALKING_LEFT)
		{
			PLAYER.src = WALKING_LEFT;
		}
	}
	else
		return;
}

function moveRight(e)
{
	if (e.which == 68 || e.keyCode == 68)
	{
		//Right
		positionX += MOVEMENT_SPEED;
		checkPlayer();
		if(PlayerFace != WALKING_RIGHT)
		{
			PLAYER.src = WALKING_RIGHT;
		}
	}
	else
		return;
}

function attack(e)
{
	if (e.which == 32 || e.keyCode == 32)
	{
		//space - attack
		checkPlayer();
		if(PlayerFace != ATTACKING_RIGHT && PlayerFace == IDLE_RIGHT)
		{
			PLAYER.src = ATTACKING_RIGHT;
		}
		else
		{
			if(PlayerFace != ATTACKING_LEFT && PlayerFace == IDLE_LEFT)
			{
				PLAYER.src = ATTACKING_LEFT;
			}
		}
		
	}
	else
		return;
}

function playerBlock(e)
{
	if (e.which == 83 || e.keyCode == 83)
	{
		//down - blocking
		checkPlayer();
		if(PlayerFace != BLOCKING_RIGHT && PlayerFace == IDLE_RIGHT)
		{
			PLAYER.src = BLOCKING_RIGHT;
		}
		else
		{
			if(PlayerFace != BLOCKING_LEFT && PlayerFace == IDLE_LEFT)
			{
				PLAYER.src = BLOCKING_LEFT;
			}
		}
	}
	else
		return;
}

function playerJump(e)
{
	function JUMP_UP()
	{
		positionY -= 4;
		posY = positionY + "px";
		PLAYER.style.top = posY;
	}
	
	function STOP_JUMP_UP()
	{
		clearInterval(Jump);
	}
	
	function START_FALL()
	{
		Falling = setInterval(FALL(), 10);
	}
	
	function FALL()
	{
		positionY += 2;
		posY = positionY + "px";
		PLAYER.style.top = posY;
		
	}
	
	function END_FALL()
	{
		clearInterval(Fall);
		jumptimes = 0;
	}
	
	if (e.which == 87 || e.keyCode == 87)
	{
		//up - jumping
		jumptimes++;
		if(jumptimes==1)
		{
		var Jump;
		var StopJump;
		var Fall;
		Jump = setInterval( 
			function()
			{
				positionY -= 2;
				posY = positionY + "px";
				PLAYER.style.top = posY;
			}, 10);
		StopJump = setTimeout( 
			function()
			{
				clearInterval(Jump);
			}, 600);
		Fall = setTimeout(
			function () 
			{
				var Falling;
				var StopFalling;
				Falling = setInterval( 
					function()
					{
						positionY += 2;
						posY = positionY + "px";
						PLAYER.style.top = posY;
					}, 10);
				StopFalling = setTimeout( 
					function()
					{
						clearInterval(Falling);
						jumptimes=0;
					}, 600);
			}, 600);
		}
	}
}

function checkKeyPressDown(e)
{
	moveLeft(e);
	moveRight(e);
	attack(e);
	playerBlock(e);
	playerJump(e);
	
	posX = positionX + "px";
	posY = positionY + "px";
	PLAYER.style.top = posY;
	PLAYER.style.left = posX;
}

function checkKeyPressUp(e)
{
	checkPlayer();
	if (e.which == 65 || e.keyCode == 65 || e.which == 68 || e.keyCode == 68 || e.which == 83 || e.keyCode == 83 || e.which == 32 || e.keyCode == 32)
	{
		if(PlayerFace == WALKING_RIGHT)
		{
			PLAYER.src = IDLE_RIGHT;
		}
		else
		{
			if(PlayerFace == WALKING_LEFT)
			{
				PLAYER.src = IDLE_LEFT;
			}
			else
			{
				if(PlayerFace == BLOCKING_LEFT)
				{
					PLAYER.src = IDLE_LEFT;
				}
				else
				{
					if(PlayerFace == BLOCKING_RIGHT)
					{
						PLAYER.src = IDLE_RIGHT;
					}
					else
					{
						if(PlayerFace == ATTACKING_LEFT)
						{
							PLAYER.src = IDLE_LEFT;
						}
						else
						{
							if(PlayerFace == ATTACKING_RIGHT)
							{
								PLAYER.src = IDLE_RIGHT;
							}
						}
					}
				}
			}
		}
	}
}